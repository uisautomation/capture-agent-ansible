#pragma once

#define VER_MAJOR						1
#define VER_MINOR						2
#define VER_RELEASE						0
#define VER_BUILD						3950
#define VER_DATE						"2018-07-13 15:35:07"
#define VER_CLASS		  "RC"
