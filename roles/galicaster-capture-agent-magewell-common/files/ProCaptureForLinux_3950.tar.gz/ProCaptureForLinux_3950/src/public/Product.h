#pragma once

#include "ProductVer.h"

#define PRODUCT_NAME		"Pro Capture Driver for Linux\0"
#define LEGAL_TRADEMARKS	"Magewell (TM)\0"
